/*
 * Home Security System - MCU2 (Remote Monitor / Commander)
 * ATmega32 @ 8MHz
 *
 * PIN MAPPING:
 *  INPUTS:
 *    PD2 (INT0)  - Remote ARM   button (active LOW)
 *    PD3 (INT1)  - Remote DISARM button (active LOW)
 *
 *  OUTPUTS (7-Segment, common cathode, on PORTB):
 *    PB0..PB6    - Segments a..g  (no decimal point needed)
 *    Displays:   'A' = Armed   'd' = disarmed   'P' = PIR alert
 *                'n' = door alert  'C' = all clear
 *
 *  OUTPUTS (status LEDs on PORTC):
 *    PC0         - ARMED indicator LED
 *    PC1         - DISARMED indicator LED
 *    PC2         - INTRUSION / ALERT LED
 *
 *  USART (to MCU1):
 *    PD0 (RXD)   - Receive from MCU1
 *    PD1 (TXD)   - Transmit to MCU1
 *
 * USART Protocol:  see MCU1 source.
 *
 * 7-Segment encoding (common cathode, active HIGH segments):
 *  Bit:  6 5 4 3 2 1 0
 *  Seg:  g f e d c b a
 *
 *  'A' = 0b1110111  (a,b,c,e,f,g)    = 0x77
 *  'd' = 0b1011110  (b,c,d,e,g)      = 0x5E  (lowercase d)
 *  'P' = 0b1110011  (a,b,e,f,g)      = 0x73
 *  'n' = 0b0010100  (c,e,g) rough n  = 0x54  (lowercase n)
 *  'C' = 0b0111001  (a,d,e,f)        = 0x39
 *  '-' = 0b1000000  (g only)         = 0x40  (idle / unknown)
 */

#define F_CPU 8000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* ?? USART ?? */
#define BAUD      9600
#define UBRR_VAL  ((F_CPU / (16UL * BAUD)) - 1)

/* ?? 7-seg patterns ?? */
#define SEG_A    0x77   /* Armed         */
#define SEG_D    0x5E   /* disarmed      */
#define SEG_P    0x73   /* PIR alert     */
#define SEG_N    0x54   /* door (n)      */
#define SEG_C    0x39   /* Clear         */
#define SEG_DASH 0x40   /* idle          */

/* ?? LED helpers ?? */
#define LED_ARM_ON()    (PORTC |=  (1 << PC0))
#define LED_ARM_OFF()   (PORTC &= ~(1 << PC0))
#define LED_DIS_ON()    (PORTC |=  (1 << PC1))
#define LED_DIS_OFF()   (PORTC &= ~(1 << PC1))
#define LED_ALERT_ON()  (PORTC |=  (1 << PC2))
#define LED_ALERT_OFF() (PORTC &= ~(1 << PC2))

/* ?? Flags from ISRs ?? */
volatile uint8_t send_arm    = 0;
volatile uint8_t send_disarm = 0;

/* ????????????????????????????????
   USART
   ???????????????????????????????? */
void usart_init(void)
{
    UBRRH = (uint8_t)(UBRR_VAL >> 8);
    UBRRL = (uint8_t) UBRR_VAL;
    UCSRB = (1 << RXEN) | (1 << TXEN) | (1 << RXCIE);
    UCSRC = (1 << URSEL) | (1 << UCSZ1) | (1 << UCSZ0);
}

void usart_send(uint8_t c)
{
    while (!(UCSRA & (1 << UDRE)));
    UDR = c;
}

/* ????????????????????????????????
   7-Segment display
   ???????????????????????????????? */
void seg_show(uint8_t pattern)
{
	
    PORTB = pattern;
}

/* ????????????????????????????????
   ISRs
   ???????????????????????????????? */

/* INT0: Remote ARM button */
ISR(INT0_vect)
{
    
 
        send_arm = 1;
}

/* INT1: Remote DISARM button */
ISR(INT1_vect)
{

        send_disarm = 1;
}

/* USART RX: status messages from MCU1 */
ISR(USART_RXC_vect)
{
    uint8_t msg = UDR;
    switch (msg) {
        case 'A':           /* Armed */
            seg_show(SEG_A);
            LED_ARM_ON();
            LED_DIS_OFF();
            LED_ALERT_OFF();
            break;

        case 'D':           /* Disarmed */
            seg_show(SEG_D);
            LED_ARM_OFF();
            LED_DIS_ON();
            LED_ALERT_OFF();
            break;

        case 'P':           /* PIR intrusion */
            seg_show(SEG_P);
            LED_ALERT_ON();
            break;

        case 'M':           /* Magnetic / door intrusion */
            seg_show(SEG_N);
            LED_ALERT_ON();
            break;

        case 'C':           /* All clear */
            seg_show(SEG_C);
            LED_ALERT_OFF();
            break;

        default: break;
    }
}

/* ????????????????????????????????
   GPIO & interrupt init
   ???????????????????????????????? */
void gpio_init(void)
{
    /* PORTB full output for 7-seg */
    DDRB  = 0xFF;
    PORTB = 0x00;

    /* PORTC[2:0] outputs (status LEDs) */
    DDRC |= (1 << PC0) | (1 << PC1) | (1 << PC2);

    /* PD2, PD3 inputs with pull-up (buttons) */
    DDRD  &= ~((1 << PD2) | (1 << PD3));
    PORTD |=  (1 << PD2) | (1 << PD3);
}

void ext_int_init(void)
{
    /* INT0 falling edge */
    MCUCR |= (1 << ISC01);
    MCUCR &= ~(1 << ISC00);
    /* INT1 falling edge */
    MCUCR |= (1 << ISC11);
    MCUCR &= ~(1 << ISC10);

    GICR |= (1 << INT0) | (1 << INT1);
}

/* ????????????????????????????????
   MAIN
   ???????????????????????????????? */
int main(void)
{
    gpio_init();
    usart_init();
    ext_int_init();
    sei();

    /* Initial display */
    seg_show(SEG_DASH);
    LED_DIS_ON();

    /* Query MCU1 for current state */
    _delay_ms(200);
    usart_send('q');

    while (1) {

        if (send_arm) {
            send_arm = 0;
            usart_send('a');
        }

        if (send_disarm) {
            send_disarm = 0;
            usart_send('d');
        }

        _delay_ms(20);
    }
    return 0;
}
