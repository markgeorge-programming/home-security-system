/*
 * Home Security System - MCU1 (Main Controller)
 * ATmega32 @ 8MHz
 *
 * PIN MAPPING:
 *  INPUTS:
 *    PD2 (INT0)  - Arm/Disarm Push Button (active LOW, external interrupt)
 *    PC0         - PIR Sensor             (active HIGH = motion detected)
 *    PC1         - Magnetic Door Sensor   (active HIGH = door opened)
 *
 *  OUTPUTS:
 *    PB0         - LED: System ARMED      (ON when armed)
 *    PB1         - LED: System DISARMED   (ON when disarmed)
 *    PB2         - LED: PIR Alert         (ON when PIR triggered)
 *    PB3         - LED: Door Alert        (ON when door triggered)
 *    PD7         - Buzzer                 (active HIGH)
 *
 *  USART (to MCU2):
 *    PD0 (RXD)   - Receive from MCU2
 *    PD1 (TXD)   - Transmit to MCU2
 *
 * USART Protocol (ASCII commands):
 *   MCU1 ? MCU2:  'A' = System Armed
 *                 'D' = System Disarmed
 *                 'P' = PIR Intrusion detected
 *                 'M' = Magnetic sensor intrusion detected
 *                 'C' = All Clear (alarm stopped)
 *   MCU2 ? MCU1:  'a' = Remote ARM command
 *                 'd' = Remote DISARM command
 *                 'q' = Query status (MCU1 replies with current state)
 */

#define F_CPU 8000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* ?? USART ?? */
#define BAUD      9600
#define UBRR_VAL  ((F_CPU / (16UL * BAUD)) - 1)   /* = 51 */

/* ?? Pin helpers ?? */
#define PIR_PIN       (PINC & (1 << PC0))
#define DOOR_PIN      (PINC & (1 << PC1))

#define LED_ARMED_ON()    (PORTB |=  (1 << PB0))
#define LED_ARMED_OFF()   (PORTB &= ~(1 << PB0))
#define LED_DISARM_ON()   (PORTB |=  (1 << PB1))
#define LED_DISARM_OFF()  (PORTB &= ~(1 << PB1))
#define LED_PIR_ON()      (PORTB |=  (1 << PB2))
#define LED_PIR_OFF()     (PORTB &= ~(1 << PB2))
#define LED_DOOR_ON()     (PORTB |=  (1 << PB3))
#define LED_DOOR_OFF()    (PORTB &= ~(1 << PB3))

#define BUZZER_ON()       (PORTD |=  (1 << PD7))
#define BUZZER_OFF()      (PORTD &= ~(1 << PD7))

/* ?? State ?? */
typedef enum { DISARMED = 0, ARMED = 1 } SystemState;
volatile SystemState state = DISARMED;
volatile uint8_t toggle_flag = 0;   /* set by INT0 ISR */

/* ????????????????????????????????
   USART
   ???????????????????????????????? */
void usart_init(void)
{
    UBRRH = (uint8_t)(UBRR_VAL >> 8);
    UBRRL = (uint8_t) UBRR_VAL;
    UCSRB = (1 << RXEN) | (1 << TXEN) | (1 << RXCIE); /* RX interrupt enabled */
    UCSRC = (1 << URSEL) | (1 << UCSZ1) | (1 << UCSZ0); /* 8-N-1 */
}

void usart_send(uint8_t c)
{
    while (!(UCSRA & (1 << UDRE)));
    UDR = c;
}

/* ????????????????????????????????
   ISRs
   ???????????????????????????????? */

/* INT0: push button (falling edge) */
ISR(INT0_vect)
{
    if (!(PIND & (1 << PD2)))   /* still LOW after debounce? */
        toggle_flag = 1;
}

/* USART RX: commands from MCU2 */
ISR(USART_RXC_vect)
{
    uint8_t cmd = UDR;
    switch (cmd) {
        case 'a': state = ARMED;    break;
        case 'd': state = DISARMED; break;
        case 'q': /* query � handled in main loop via toggle_flag trick;
                     send current state immediately */
            usart_send((state == ARMED) ? 'A' : 'D');
            break;
        default: break;
    }
}

/* ????????????????????????????????
   Helper: update LEDs for state
   ???????????????????????????????? */
void update_state_leds(void)
{
    if (state == ARMED) {
        LED_ARMED_ON();
        LED_DISARM_OFF();
    } else {
        LED_ARMED_OFF();
        LED_DISARM_ON();
        /* also clear alert LEDs and buzzer when disarmed */
        LED_PIR_OFF();
        LED_DOOR_OFF();
        BUZZER_OFF();
    }
}

/* ????????????????????????????????
   Peripheral init
   ???????????????????????????????? */
void gpio_init(void)
{
    /* PORTB[3:0] outputs (LEDs) */
    DDRB |= (1 << PB0) | (1 << PB1) | (1 << PB2) | (1 << PB3);

    /* PORTD7 output (buzzer), PD2 input (button) */
    DDRD |= (1 << PD7);
    DDRD &= ~(1 << PD2);
    PORTD |= (1 << PD2);   /* internal pull-up on PD2 */

    /* PORTC[1:0] inputs (sensors) */
    DDRC &= ~((1 << PC0) | (1 << PC1));
    PORTC &= ~((1 << PC0) | (1 << PC1)); /* no pull-up; sensor drives HIGH */
}

void int0_init(void)
{
    /* Falling edge on INT0 */
    MCUCR |= (1 << ISC01);
    MCUCR &= ~(1 << ISC00);
    GICR  |= (1 << INT0);
}

/* ????????????????????????????????
   MAIN
   ???????????????????????????????? */
int main(void)
{
    gpio_init();
    usart_init();
    int0_init();
    sei();

    /* Start disarmed */
    state = DISARMED;
    update_state_leds();
    usart_send('D');

    uint8_t prev_state = DISARMED;

    while (1) {

        /* ?? Handle button toggle ?? */
        if (toggle_flag) {
            toggle_flag = 0;
            state = (state == ARMED) ? DISARMED : ARMED;
            update_state_leds();
            usart_send((state == ARMED) ? 'A' : 'D');
        }

        /* ?? Notify MCU2 if state changed remotely ?? */
        if ((uint8_t)state != prev_state) {
            update_state_leds();
            prev_state = (uint8_t)state;
        }

        /* ?? Sensor scanning (only when ARMED) ?? */
        if (state == ARMED) {
            uint8_t pir_trig  = (PIR_PIN  != 0);
            uint8_t door_trig = (DOOR_PIN != 0);

            if (pir_trig) {
                LED_PIR_ON();
                BUZZER_ON();
                usart_send('P');
              
            } else {
                LED_PIR_OFF();
            }

            if (door_trig) {
                LED_DOOR_ON();
                BUZZER_ON();
                usart_send('M');
              
            } else {
                LED_DOOR_OFF();
            }

            if (!pir_trig && !door_trig) {
                BUZZER_OFF();
                usart_send('C');
                
            }
        }

        _delay_ms(10);
    }
    return 0;
}
